import psutil
import platform
import os
import json
import logging
from datetime import datetime
from telebot import TeleBot
from utils.helpers import add_watermark, format_bytes
from pathlib import Path

class SystemHandler:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)

    def register_handlers(self):
        """Register all system handlers"""
        self.bot.message_handler(commands=['system'])(self.show_system_menu)
        self.bot.message_handler(commands=['server_info'])(self.server_info)
        self.bot.message_handler(commands=['server_full'])(self.server_full)
        self.bot.message_handler(commands=['server_status'])(self.server_status)
        self.bot.message_handler(commands=['log_show'])(self.show_logs)
        self.bot.message_handler(commands=['log_search'])(self.search_logs)
        self.bot.message_handler(commands=['log_export'])(self.export_logs)
        self.bot.message_handler(commands=['status_services'])(self.check_services)
        self.bot.message_handler(commands=['status_ports'])(self.check_ports)
        self.bot.message_handler(commands=['status_updates'])(self.check_updates)
        self.bot.message_handler(commands=['system_monitor'])(self.system_monitor)
        self.bot.message_handler(commands=['system_process'])(self.list_processes)
        self.bot.message_handler(commands=['system_kill'])(self.kill_process)

    def show_system_menu(self, message):
        """Show system tools menu"""
        system_text = """
⚙️ Alat Sistem:

1. Informasi Server:
/server_info - Info dasar server
/server_full - Info lengkap server
/server_status - Status server saat ini

2. Manajemen Log:
/log_show - Tampilkan log terbaru
/log_search [kata] - Cari dalam log
/log_export - Ekspor log sistem

3. Status Sistem:
/status_services - Status layanan
/status_ports - Port yang terbuka
/status_updates - Update sistem

4. Monitor & Proses:
/system_monitor - Monitor real-time
/system_process - Daftar proses
/system_kill [pid] - Matikan proses

Contoh: 
- /server_info
- /log_search error
- /system_kill 1234
"""
        self.bot.reply_to(message, system_text)

    def server_info(self, message):
        """Show basic server information"""
        try:
            info = {
                "System": platform.system(),
                "Node": platform.node(),
                "Release": platform.release(),
                "Version": platform.version(),
                "Machine": platform.machine(),
                "Processor": platform.processor(),
                "CPU Cores": psutil.cpu_count(),
                "Memory Total": format_bytes(psutil.virtual_memory().total)
            }
            
            result = "🖥️ Informasi Server:\n\n"
            for key, value in info.items():
                result += f"{key}: {value}\n"
                
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in server_info: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan informasi server")

    def server_full(self, message):
        """Show detailed server information"""
        try:
            # System information
            uname = platform.uname()
            boot_time = datetime.fromtimestamp(psutil.boot_time())
            
            # CPU information
            cpu_freq = psutil.cpu_freq()
            cpu_percent = psutil.cpu_percent(interval=1, percpu=True)
            
            # Memory information
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            # Disk information
            disk = psutil.disk_usage('/')
            
            result = f"""📊 Informasi Lengkap Server:

🖥️ Sistem:
└─ Sistem: {uname.system}
└─ Nama Host: {uname.node}
└─ Rilis: {uname.release}
└─ Versi: {uname.version}
└─ Mesin: {uname.machine}
└─ Prosesor: {uname.processor}
└─ Waktu Hidup: {boot_time.strftime('%Y-%m-%d %H:%M:%S')}

💻 CPU:
└─ Core Fisik: {psutil.cpu_count(logical=False)}
└─ Total Core: {psutil.cpu_count(logical=True)}
└─ Frekuensi Max: {cpu_freq.max:.2f}Mhz
└─ Frekuensi Min: {cpu_freq.min:.2f}Mhz
└─ Frekuensi Current: {cpu_freq.current:.2f}Mhz
└─ Penggunaan Per CPU: {cpu_percent}%

💾 Memory:
└─ Total: {format_bytes(memory.total)}
└─ Tersedia: {format_bytes(memory.available)}
└─ Terpakai: {format_bytes(memory.used)}
└─ Persentase: {memory.percent}%

💿 Swap:
└─ Total: {format_bytes(swap.total)}
└─ Terpakai: {format_bytes(swap.used)}
└─ Bebas: {format_bytes(swap.free)}
└─ Persentase: {swap.percent}%

💽 Disk:
└─ Total: {format_bytes(disk.total)}
└─ Terpakai: {format_bytes(disk.used)}
└─ Bebas: {format_bytes(disk.free)}
└─ Persentase: {disk.percent}%
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in server_full: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan informasi lengkap server")

    def server_status(self, message):
        """Show current server status"""
        try:
            status = {
                "CPU Usage": f"{psutil.cpu_percent()}%",
                "Memory Usage": f"{psutil.virtual_memory().percent}%",
                "Disk Usage": f"{psutil.disk_usage('/').percent}%",
                "Network": self.get_network_status(),
                "Load Average": os.getloadavg(),
                "Active Users": len(psutil.users()),
                "Running Processes": len(psutil.pids())
            }
            
            result = "📊 Status Server:\n\n"
            for key, value in status.items():
                result += f"{key}: {value}\n"
                
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in server_status: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan status server")

    def show_logs(self, message):
        """Show recent system logs"""
        try:
            log_path = Path('logs/bot.log')
            if not log_path.exists():
                self.bot.reply_to(message, "❌ File log tidak ditemukan")
                return
                
            # Read last 10 lines
            with open(log_path, 'r') as f:
                logs = f.readlines()[-10:]
                
            result = "📋 Log Terbaru:\n\n"
            for log in logs:
                result += f"{log.strip()}\n"
                
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in show_logs: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal membaca log sistem")

    def search_logs(self, message):
        """Search in system logs"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /log_search [kata_kunci]")
                return
                
            keyword = args[1].lower()
            log_path = Path('logs/bot.log')
            
            if not log_path.exists():
                self.bot.reply_to(message, "❌ File log tidak ditemukan")
                return
                
            matching_logs = []
            with open(log_path, 'r') as f:
                for line in f:
                    if keyword in line.lower():
                        matching_logs.append(line.strip())
                        
            if matching_logs:
                result = f"🔍 Hasil pencarian untuk '{keyword}':\n\n"
                result += "\n".join(matching_logs[-10:])  # Last 10 matches
            else:
                result = f"❌ Tidak ditemukan hasil untuk '{keyword}'"
                
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in search_logs: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mencari dalam log")

    def check_services(self, message):
        """Check status of system services"""
        try:
            services = []
            for proc in psutil.process_iter(['name', 'status']):
                try:
                    pinfo = proc.info
                    services.append({
                        'name': pinfo['name'],
                        'status': pinfo['status']
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
                    
            result = "🔧 Status Layanan:\n\n"
            for service in sorted(services, key=lambda x: x['name'])[:15]:  # Show first 15
                status_emoji = "✅" if service['status'] == 'running' else "❌"
                result += f"{status_emoji} {service['name']}: {service['status']}\n"
                
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in check_services: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal memeriksa layanan")

    def check_ports(self, message):
        """Check open ports"""
        try:
            import socket
            common_ports = [21, 22, 23, 25, 80, 443, 3306, 8080]
            result = "🔌 Port yang Terbuka:\n\n"
            
            for port in common_ports:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                if sock.connect_ex(('localhost', port)) == 0:
                    result += f"✅ Port {port}: Terbuka\n"
                else:
                    result += f"❌ Port {port}: Tertutup\n"
                sock.close()
                
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in check_ports: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal memeriksa port")

    def check_updates(self, message):
        """Check system updates"""
        try:
            # This is a simplified version. In real implementation,
            # you might want to check actual system updates using
            # system-specific commands (apt, yum, etc.)
            result = """🔄 Status Update Sistem:

✅ Sistem Operasi: Up to date
✅ Paket Sistem: Up to date
✅ Keamanan: Up to date
✅ Aplikasi: Up to date

Terakhir dicek: {}""".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in check_updates: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal memeriksa update")

    def system_monitor(self, message):
        """Monitor system resources in real-time"""
        try:
            # Get current system statistics
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            network = psutil.net_io_counters()
            
            result = f"""📊 Monitor Sistem Real-time:

💻 CPU: {cpu_percent}%
└─ Per Core: {psutil.cpu_percent(interval=1, percpu=True)}

💾 Memory:
└─ Terpakai: {memory.percent}%
└─ Tersedia: {format_bytes(memory.available)}

💽 Disk:
└─ Terpakai: {disk.percent}%
└─ Tersedia: {format_bytes(disk.free)}

🌐 Network:
└─ Upload: {format_bytes(network.bytes_sent)}
└─ Download: {format_bytes(network.bytes_recv)}

⏰ Waktu: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in system_monitor: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal memonitor sistem")

    def list_processes(self, message):
        """List running processes"""
        try:
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
                try:
                    pinfo = proc.info
                    processes.append({
                        'pid': pinfo['pid'],
                        'name': pinfo['name'],
                        'cpu': pinfo['cpu_percent'],
                        'memory': pinfo['memory_percent']
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
                    
            # Sort by CPU usage and get top 10
            processes.sort(key=lambda x: x['cpu'], reverse=True)
            top_processes = processes[:10]
            
            result = "📊 Proses Teratas:\n\n"
            for proc in top_processes:
                result += f"PID: {proc['pid']}\n"
                result += f"└─ Nama: {proc['name']}\n"
                result += f"└─ CPU: {proc['cpu']:.1f}%\n"
                result += f"└─ Memory: {proc['memory']:.1f}%\n\n"
                
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in list_processes: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan daftar proses")

    def kill_process(self, message):
        """Kill a process by PID"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /system_kill [pid]")
                return
                
            try:
                pid = int(args[1])
            except ValueError:
                self.bot.reply_to(message, "❌ PID harus berupa angka")
                return
                
            process = psutil.Process(pid)
            process_name = process.name()
            process.terminate()
            
            result = f"✅ Proses berhasil dihentikan:\n"
            result += f"└─ PID: {pid}\n"
            result += f"└─ Nama: {process_name}"
            
            self.bot.reply_to(message, add_watermark(result))
            
        except psutil.NoSuchProcess:
            self.bot.reply_to(message, f"❌ Proses dengan PID {pid} tidak ditemukan")
        except psutil.AccessDenied:
            self.bot.reply_to(message, f"❌ Akses ditolak untuk menghentikan proses {pid}")
        except Exception as e:
            self.logger.error(f"Error in kill_process: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal menghentikan proses")

    def get_network_status(self):
        """Get network status information"""
        try:
            net = psutil.net_io_counters()
            return f"↑ {format_bytes(net.bytes_sent)} | ↓ {format_bytes(net.bytes_recv)}"
        except:
            return "Tidak tersedia"

def register_system_handlers(bot: TeleBot):
    handler = SystemHandler(bot)
    handler.register_handlers()