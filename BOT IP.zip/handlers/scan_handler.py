import socket
import requests
from telebot import TeleBot
from utils.helpers import add_watermark

def register_scan_handlers(bot: TeleBot):
    @bot.message_handler(commands=['scan'])
    def show_scan_menu(message):
        scan_text = """
🔍 Alat Pemindaian:

1. Informasi IP:
/ip_cek [ip] - Info IP dasar
/ip_detail [ip] - Info IP lengkap
/ip_lokasi [ip] - Lokasi IP

2. Pemindaian Port:
/port_dasar [ip] - Pindai port dasar
/port_lengkap [ip] - Pindai port lengkap
/port_layanan [ip] - Deteksi layanan

3. Pemindaian Jaringan:
/net_pindai [range] - Pindai rentang jaringan
/net_perangkat [range] - Temukan perangkat aktif
/net_os [ip] - Deteksi sistem operasi

Contoh: /ip_cek 8.8.8.8
"""
        bot.reply_to(message, scan_text)

    @bot.message_handler(commands=['ip_cek'])
    def ip_check(message):
        try:
            ip = message.text.split()[1]
            response = requests.get(f'http://ip-api.com/json/{ip}')
            data = response.json()
            
            if data['status'] == 'success':
                result = f"""📍 Informasi IP: {ip}
                
🌍 Negara: {data.get('country', 'N/A')}
🏢 Kota: {data.get('city', 'N/A')}
🌐 ISP: {data.get('isp', 'N/A')}
🏢 Organisasi: {data.get('org', 'N/A')}
🌍 Wilayah: {data.get('regionName', 'N/A')}
⏰ Zona Waktu: {data.get('timezone', 'N/A')}
📍 Latitude: {data.get('lat', 'N/A')}
📍 Longitude: {data.get('lon', 'N/A')}"""
            else:
                result = "❌ Gagal mendapatkan informasi IP"
                
            bot.reply_to(message, add_watermark(result))
        except:
            bot.reply_to(message, "Format: /ip_cek [ip]")