import os
import json
import csv
import pandas as pd
from datetime import datetime
from telebot import TeleBot
from pathlib import Path
from utils.helpers import add_watermark
import logging
from utils.setup import BotSetup

from utils.setup import BotSetup

class ExportHandler:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.setup = BotSetup()
        self.export_path = self.setup.get_path('exports')
        self.logger = logging.getLogger(__name__)

class ExportHandler:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.export_path = Path('exports')
        self.export_path.mkdir(exist_ok=True)
        self.logger = logging.getLogger(__name__)

    def register_handlers(self):
        """Register all export handlers"""
        self.bot.message_handler(commands=['export'])(self.show_export_menu)
        self.bot.message_handler(commands=['ekspor_pdf'])(self.export_pdf)
        self.bot.message_handler(commands=['ekspor_csv'])(self.export_csv)
        self.bot.message_handler(commands=['ekspor_json'])(self.export_json)
        self.bot.message_handler(commands=['data_backup'])(self.data_backup)
        self.bot.message_handler(commands=['data_log'])(self.export_logs)
        self.bot.message_handler(commands=['data_stat'])(self.export_stats)
        self.bot.message_handler(commands=['laporan_custom'])(self.custom_report)

    def show_export_menu(self, message):
        """Show export tools menu"""
        export_text = """
📤 Alat Ekspor:

1. Ekspor Laporan:
/ekspor_pdf - Ekspor ke PDF
/ekspor_csv - Ekspor ke CSV
/ekspor_json - Ekspor ke JSON

2. Ekspor Data:
/data_backup - Backup data
/data_log - Ekspor log
/data_stat - Ekspor statistik

3. Ekspor Kustom:
/laporan_custom [tipe] - Laporan kustom
  └─ Tipe: daily, weekly, monthly
/laporan_periode [hari] - Laporan periode
/laporan_format [format] - Format spesifik

Contoh: 
- /ekspor_pdf
- /laporan_custom daily
"""
        self.bot.reply_to(message, export_text)

    def export_pdf(self, message):
        """Export data to PDF"""
        try:
            # Create timestamp for filename
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'report_{timestamp}.pdf'
            filepath = self.export_path / filename

            # Generate PDF using reportlab
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import letter
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
            from reportlab.lib.styles import getSampleStyleSheet

            doc = SimpleDocTemplate(str(filepath), pagesize=letter)
            styles = getSampleStyleSheet()
            story = []

            # Add title
            title = Paragraph("Network Tools Bot Report", styles['Heading1'])
            story.append(title)
            story.append(Spacer(1, 12))

            # Add system information
            import psutil
            cpu_percent = psutil.cpu_percent()
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')

            data = [
                ['Metric', 'Value'],
                ['CPU Usage', f'{cpu_percent}%'],
                ['Memory Usage', f'{memory.percent}%'],
                ['Disk Usage', f'{disk.percent}%'],
                ['Generated', datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
            ]

            table = Table(data)
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 14),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 12),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            story.append(table)

            # Build PDF
            doc.build(story)

            # Send PDF file
            with open(filepath, 'rb') as f:
                self.bot.send_document(
                    message.chat.id,
                    f,
                    caption=add_watermark("📊 Laporan PDF berhasil dibuat")
                )

            # Cleanup
            os.remove(filepath)

        except Exception as e:
            self.logger.error(f"Error in PDF export: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal membuat laporan PDF")

    def export_csv(self, message):
        """Export data to CSV"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'data_{timestamp}.csv'
            filepath = self.export_path / filename

            # Generate sample data
            import psutil
            data = []
            # Collect system metrics
            for i in range(5):  # Last 5 minutes
                cpu = psutil.cpu_percent()
                memory = psutil.virtual_memory()
                disk = psutil.disk_usage('/')
                data.append({
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'cpu_usage': cpu,
                    'memory_usage': memory.percent,
                    'disk_usage': disk.percent
                })

            # Write to CSV
            with open(filepath, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=data[0].keys())
                writer.writeheader()
                writer.writerows(data)

            # Send CSV file
            with open(filepath, 'rb') as f:
                self.bot.send_document(
                    message.chat.id,
                    f,
                    caption=add_watermark("📊 Data CSV berhasil diekspor")
                )

            # Cleanup
            os.remove(filepath)

        except Exception as e:
            self.logger.error(f"Error in CSV export: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mengekspor data CSV")

    def export_json(self, message):
        """Export data to JSON"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'data_{timestamp}.json'
            filepath = self.export_path / filename

            # Generate sample data
            import psutil
            data = {
                'system_info': {
                    'cpu_usage': psutil.cpu_percent(),
                    'memory_usage': psutil.virtual_memory()._asdict(),
                    'disk_usage': psutil.disk_usage('/')._asdict(),
                    'network': psutil.net_io_counters()._asdict()
                },
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'export_info': {
                    'type': 'json',
                    'version': '1.0'
                }
            }

            # Write to JSON
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=4)

            # Send JSON file
            with open(filepath, 'rb') as f:
                self.bot.send_document(
                    message.chat.id,
                    f,
                    caption=add_watermark("📊 Data JSON berhasil diekspor")
                )

            # Cleanup
            os.remove(filepath)

        except Exception as e:
            self.logger.error(f"Error in JSON export: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mengekspor data JSON")

    def data_backup(self, message):
        """Create data backup"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'backup_{timestamp}.zip'
            filepath = self.export_path / filename

            import zipfile
            import shutil

            # Create zip file
            with zipfile.ZipFile(filepath, 'w', zipfile.ZIP_DEFLATED) as zipf:
                # Add logs
                if Path('logs').exists():
                    for log_file in Path('logs').glob('*.log'):
                        zipf.write(log_file, f'logs/{log_file.name}')

                # Add configs (excluding sensitive data)
                if Path('config').exists():
                    config_example = {
                        'version': '1.0',
                        'backup_date': datetime.now().isoformat()
                    }
                    with open(self.export_path / 'config_example.json', 'w') as f:
                        json.dump(config_example, f, indent=4)
                    zipf.write(self.export_path / 'config_example.json', 'config/config_example.json')

                # Add exports
                for export_file in self.export_path.glob('*.*'):
                    if export_file.suffix in ['.csv', '.json', '.pdf']:
                        zipf.write(export_file, f'exports/{export_file.name}')

            # Send backup file
            with open(filepath, 'rb') as f:
                self.bot.send_document(
                    message.chat.id,
                    f,
                    caption=add_watermark("📦 Backup data berhasil dibuat")
                )

            # Cleanup
            os.remove(filepath)

        except Exception as e:
            self.logger.error(f"Error in backup creation: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal membuat backup data")

    def export_logs(self, message):
        """Export system logs"""
        try:
            if not Path('logs').exists():
                self.bot.reply_to(message, "❌ Tidak ada log untuk diekspor")
                return

            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'logs_{timestamp}.zip'
            filepath = self.export_path / filename

            # Create zip file with logs
            import zipfile
            with zipfile.ZipFile(filepath, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for log_file in Path('logs').glob('*.log'):
                    zipf.write(log_file, log_file.name)

            # Send logs
            with open(filepath, 'rb') as f:
                self.bot.send_document(
                    message.chat.id,
                    f,
                    caption=add_watermark("📋 Log sistem berhasil diekspor")
                )

            # Cleanup
            os.remove(filepath)

        except Exception as e:
            self.logger.error(f"Error in log export: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mengekspor log sistem")

    def export_stats(self, message):
        """Export system statistics"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'stats_{timestamp}.xlsx'
            filepath = self.export_path / filename

            # Generate statistics
            import psutil
            stats_data = {
                'CPU': [],
                'Memory': [],
                'Disk': [],
                'Network': []
            }

            # Collect data for 5 seconds
            for _ in range(5):
                stats_data['CPU'].append(psutil.cpu_percent())
                mem = psutil.virtual_memory()
                stats_data['Memory'].append(mem.percent)
                disk = psutil.disk_usage('/')
                stats_data['Disk'].append(disk.percent)
                net = psutil.net_io_counters()
                stats_data['Network'].append(net.bytes_sent + net.bytes_recv)

            # Create Excel file with multiple sheets
            with pd.ExcelWriter(filepath, engine='xlsxwriter') as writer:
                # Summary sheet
                summary_data = {
                    'Metric': ['CPU Average', 'Memory Average', 'Disk Usage', 'Network Traffic'],
                    'Value': [
                        f"{sum(stats_data['CPU'])/len(stats_data['CPU']):.2f}%",
                        f"{sum(stats_data['Memory'])/len(stats_data['Memory']):.2f}%",
                        f"{sum(stats_data['Disk'])/len(stats_data['Disk']):.2f}%",
                        f"{sum(stats_data['Network'])/len(stats_data['Network'])/1024/1024:.2f} MB"
                    ]
                }
                pd.DataFrame(summary_data).to_excel(writer, sheet_name='Summary', index=False)

                # Detailed sheets
                for metric, data in stats_data.items():
                    df = pd.DataFrame({
                        'Timestamp': [datetime.now().strftime('%H:%M:%S.%f')[:-3] for _ in data],
                        'Value': data
                    })
                    df.to_excel(writer, sheet_name=metric, index=False)

            # Send statistics file
            with open(filepath, 'rb') as f:
                self.bot.send_document(
                    message.chat.id,
                    f,
                    caption=add_watermark("📊 Statistik sistem berhasil diekspor")
                )

            # Cleanup
            os.remove(filepath)

        except Exception as e:
            self.logger.error(f"Error in stats export: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mengekspor statistik sistem")

    def custom_report(self, message):
        """Generate custom report"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /laporan_custom [daily|weekly|monthly]")
                return

            report_type = args[1].lower()
            if report_type not in ['daily', 'weekly', 'monthly']:
                self.bot.reply_to(message, "Tipe laporan tidak valid. Gunakan: daily, weekly, atau monthly")
                return

            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'custom_report_{report_type}_{timestamp}.pdf'
            filepath = self.export_path / filename

            # Generate custom report
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import letter
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table
            from reportlab.lib.styles import getSampleStyleSheet

            doc = SimpleDocTemplate(str(filepath), pagesize=letter)
            styles = getSampleStyleSheet()
            story = []

            # Add title
            title = Paragraph(f"Custom {report_type.capitalize()} Report", styles['Heading1'])
            story.append(title)
            story.append(Spacer(1, 12))

            # Add report content based on type
            if report_type == 'daily':
                # Daily statistics
                import psutil
                data = [
                    ['Metric', 'Value'],
                    ['CPU Usage', f'{psutil.cpu_percent()}%'],
                    ['Memory Usage', f'{psutil.virtual_memory().percent}%'],
                    ['Disk Usage', f'{psutil.disk_usage("/").percent}%'],
                    ['Network IO', f'{psutil.net_io_counters().bytes_sent/1024/1024:.2f} MB sent'],
                    ['Generated', datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
                ]
            elif report_type == 'weekly':
                # Weekly summary
                data = [
                    ['Day', 'Status'],
                    ['Monday', 'OK'],
                    ['Tuesday', 'OK'],
                    ['Wednesday', 'Warning'],
                    ['Thursday', 'OK'],
                    ['Friday', 'OK'],
                    ['Saturday', 'OK'],
                    ['Sunday', 'OK']
                ]
            else:  # monthly
                # Monthly overview
                data = [
                    ['Week', 'Performance'],
                    ['Week 1', '98%'],
                    ['Week 2', '97%'],
                    ['Week 3', '99%'],
                    ['Week 4', '96%']
                ]

            table = Table(data)
            story.append(table)

            # Build PDF
            doc.build(story)

            # Send report
            with open(filepath, 'rb') as f:
                self.bot.send_document(
                    message.chat.id,
                    f,
                    caption=add_watermark(f"📊 Laporan {report_type} berhasil dibuat")
                )

            # Cleanup
            os.remove(filepath)

        except Exception as e:
            self.logger.error(f"Error in custom report: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal membuat laporan kustom")

def register_export_handlers(bot: TeleBot):
    handler = ExportHandler(bot)
    handler.register_handlers()