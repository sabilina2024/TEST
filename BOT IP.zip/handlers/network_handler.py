import socket
import dns.resolver
import whois
import requests
import subprocess
import platform
import logging
import json
from datetime import datetime
from telebot import TeleBot
from utils.helpers import add_watermark
from pathlib import Path

class NetworkHandler:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
        self.dns_cache = {}
        self.whois_cache = {}

    def register_handlers(self):
        """Register all network handlers"""
        self.bot.message_handler(commands=['network'])(self.show_network_menu)
        # DNS Tools
        self.bot.message_handler(commands=['dns_cek'])(self.check_dns)
        self.bot.message_handler(commands=['dns_record'])(self.dns_records)
        self.bot.message_handler(commands=['dns_propagasi'])(self.dns_propagation)
        # Connectivity Tools
        self.bot.message_handler(commands=['ping'])(self.ping_host)
        self.bot.message_handler(commands=['traceroute'])(self.traceroute)
        self.bot.message_handler(commands=['mtr'])(self.mtr_report)
        # Whois Tools
        self.bot.message_handler(commands=['whois_domain'])(self.whois_domain)
        self.bot.message_handler(commands=['whois_ip'])(self.whois_ip)
        self.bot.message_handler(commands=['whois_asn'])(self.whois_asn)
        # Additional Network Tools
        self.bot.message_handler(commands=['port_scan'])(self.port_scan)
        self.bot.message_handler(commands=['ssl_check'])(self.ssl_check)
        self.bot.message_handler(commands=['http_headers'])(self.http_headers)

    def show_network_menu(self, message):
        """Show network tools menu"""
        network_text = """
🌐 Alat Jaringan:

1. Alat DNS:
/dns_cek [domain] - Cek DNS
/dns_record [domain] - Record DNS
/dns_propagasi [domain] - Propagasi DNS

2. Alat Konektivitas:
/ping [host] - Tes ping
/traceroute [host] - Traceroute
/mtr [host] - Laporan MTR

3. Alat Whois:
/whois_domain [domain] - Whois domain
/whois_ip [ip] - Whois IP
/whois_asn [asn] - Whois ASN

4. Alat Tambahan:
/port_scan [host] - Scan port
/ssl_check [domain] - Cek SSL
/http_headers [url] - Cek HTTP headers

Contoh:
- /dns_cek google.com
- /ping 8.8.8.8
"""
        self.bot.reply_to(message, network_text)

    def check_dns(self, message):
        """Check DNS resolution"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /dns_cek [domain]")
                return

            domain = args[1]
            resolver = dns.resolver.Resolver()
            
            # Get A record
            a_records = resolver.resolve(domain, 'A')
            # Get AAAA record
            try:
                aaaa_records = resolver.resolve(domain, 'AAAA')
            except:
                aaaa_records = []
            # Get MX record
            try:
                mx_records = resolver.resolve(domain, 'MX')
            except:
                mx_records = []

            result = f"""🔍 DNS Check untuk {domain}:

📍 A Records:
{self.format_dns_records(a_records)}

🌐 AAAA Records:
{self.format_dns_records(aaaa_records)}

📧 MX Records:
{self.format_dns_records(mx_records)}
"""
            self.bot.reply_to(message, add_watermark(result))

        except dns.resolver.NXDOMAIN:
            self.bot.reply_to(message, f"❌ Domain {domain} tidak ditemukan")
        except Exception as e:
            self.logger.error(f"Error in check_dns: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal melakukan DNS check")

    def dns_records(self, message):
        """Get all DNS records"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /dns_record [domain]")
                return

            domain = args[1]
            resolver = dns.resolver.Resolver()
            record_types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'SOA', 'CNAME']
            
            result = f"📋 DNS Records untuk {domain}:\n\n"
            
            for record_type in record_types:
                try:
                    answers = resolver.resolve(domain, record_type)
                    result += f"📍 {record_type} Records:\n"
                    result += self.format_dns_records(answers)
                    result += "\n"
                except:
                    result += f"📍 {record_type} Records: Tidak ditemukan\n\n"

            self.bot.reply_to(message, add_watermark(result))

        except Exception as e:
            self.logger.error(f"Error in dns_records: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan DNS records")

    def dns_propagation(self, message):
        """Check DNS propagation"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /dns_propagasi [domain]")
                return

            domain = args[1]
            dns_servers = {
                'Google': '8.8.8.8',
                'Cloudflare': '1.1.1.1',
                'OpenDNS': '208.67.222.222',
                'Quad9': '9.9.9.9'
            }
            
            result = f"🌍 Propagasi DNS untuk {domain}:\n\n"
            
            for server_name, server_ip in dns_servers.items():
                try:
                    resolver = dns.resolver.Resolver()
                    resolver.nameservers = [server_ip]
                    answers = resolver.resolve(domain, 'A')
                    ips = [rdata.address for rdata in answers]
                    result += f"📍 {server_name} ({server_ip}):\n"
                    result += f"└─ {', '.join(ips)}\n\n"
                except:
                    result += f"📍 {server_name} ({server_ip}):\n"
                    result += "└─ Tidak dapat resolv\n\n"

            self.bot.reply_to(message, add_watermark(result))

        except Exception as e:
            self.logger.error(f"Error in dns_propagation: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal memeriksa propagasi DNS")

    def ping_host(self, message):
        """Ping a host"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /ping [host]")
                return

            host = args[1]
            
            # Different ping command based on OS
            if platform.system().lower() == "windows":
                command = ["ping", "-n", "4", host]
            else:
                command = ["ping", "-c", "4", host]
            
            process = subprocess.Popen(command, 
                                     stdout=subprocess.PIPE, 
                                     stderr=subprocess.PIPE)
            output, error = process.communicate()
            
            result = f"🏓 Ping ke {host}:\n\n"
            result += output.decode('utf-8')

            self.bot.reply_to(message, add_watermark(result))

        except Exception as e:
            self.logger.error(f"Error in ping_host: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal melakukan ping")

    def traceroute(self, message):
        """Perform traceroute"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /traceroute [host]")
                return

            host = args[1]
            
            # Different traceroute command based on OS
            if platform.system().lower() == "windows":
                command = ["tracert", host]
            else:
                command = ["traceroute", "-m", "15", host]
            
            process = subprocess.Popen(command, 
                                     stdout=subprocess.PIPE, 
                                     stderr=subprocess.PIPE)
            output, error = process.communicate()
            
            result = f"🛣️ Traceroute ke {host}:\n\n"
            result += output.decode('utf-8')

            self.bot.reply_to(message, add_watermark(result))

        except Exception as e:
            self.logger.error(f"Error in traceroute: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal melakukan traceroute")

    def mtr_report(self, message):
        """Generate MTR report"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /mtr [host]")
                return

            host = args[1]
            
            # Check if mtr is installed
            if platform.system().lower() == "windows":
                self.bot.reply_to(message, "❌ MTR tidak tersedia di Windows")
                return
                
            command = ["mtr", "-r", "-c", "4", host]
            process = subprocess.Popen(command, 
                                     stdout=subprocess.PIPE, 
                                     stderr=subprocess.PIPE)
            output, error = process.communicate()
            
            result = f"📊 MTR Report ke {host}:\n\n"
            result += output.decode('utf-8')

            self.bot.reply_to(message, add_watermark(result))

        except Exception as e:
            self.logger.error(f"Error in mtr_report: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal membuat MTR report")

    def whois_domain(self, message):
        """Get domain WHOIS information"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /whois_domain [domain]")
                return

            domain = args[1]
            
            # Check cache first
            if domain in self.whois_cache:
                result = self.whois_cache[domain]
            else:
                w = whois.whois(domain)
                result = f"""🔍 WHOIS untuk {domain}:

📝 Registrar: {w.registrar}
📅 Tanggal Dibuat: {w.creation_date}
📅 Tanggal Kedaluwarsa: {w.expiration_date}
👤 Registrant: {w.name}
🏢 Organization: {w.org}
🌍 Negara: {w.country}

📧 Email: {w.emails}
🔒 Status: {w.status}
🖥️ Nameservers: {w.name_servers}
"""
                # Cache the result
                self.whois_cache[domain] = result

            self.bot.reply_to(message, add_watermark(result))

        except Exception as e:
            self.logger.error(f"Error in whois_domain: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan informasi WHOIS")

    def whois_ip(self, message):
        """Get IP WHOIS information"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /whois_ip [ip]")
                return

            ip = args[1]
            
            # Use ipwhois API
            response = requests.get(f"http://ip-api.com/json/{ip}")
            data = response.json()
            
            if data['status'] == 'success':
                result = f"""🔍 IP WHOIS untuk {ip}:

🌍 Negara: {data.get('country', 'N/A')}
🏢 ISP: {data.get('isp', 'N/A')}
🏢 Organization: {data.get('org', 'N/A')}
🌆 Kota: {data.get('city', 'N/A')}
📍 Region: {data.get('regionName', 'N/A')}
⏰ Timezone: {data.get('timezone', 'N/A')}
📍 Koordinat: {data.get('lat', 'N/A')}, {data.get('lon', 'N/A')}
"""
            else:
                result = "❌ Gagal mendapatkan informasi IP"

            self.bot.reply_to(message, add_watermark(result))

        except Exception as e:
            self.logger.error(f"Error in whois_ip: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan informasi IP WHOIS")

    def whois_asn(self, message):
        """Get ASN information"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /whois_asn [asn]")
                return

            asn = args[1].upper()
            if not asn.startswith('AS'):
                asn = 'AS' + asn
                
            # Use RADB whois
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect(("whois.radb.net", 43))
            sock.send(f"{asn}\r\n".encode())
            
            response = ""
            while True:
                data = sock.recv(4096)
                if not data:
                    break
                response += data.decode()
            
            sock.close()
            
            result = f"🔍 ASN WHOIS untuk {asn}:\n\n"
            result += response

            self.bot.reply_to(message, add_watermark(result))

        except Exception as e:
            self.logger.error(f"Error in whois_asn: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan informasi ASN")

    def port_scan(self, message):
        """Scan common ports"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /port_scan [host]")
                return

            host = args[1]
            common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 465, 587, 993, 995, 3306, 3389, 5432, 8080]
            
            result = f"🔍 Hasil Scan Port untuk {host}:\n\n"
            
            for port in common_ports:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                status = sock.connect_ex((host, port))
                if status == 0:
                    service = socket.getservbyport(port)
                    result += f"✅ Port {port} ({service}): Terbuka\n"
                sock.close()

            self.bot.reply_to(message, add_watermark(result))

        except Exception as e:
            self.logger.error(f"Error in port_scan: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal melakukan scan port")

    def ssl_check(self, message):
        """Check SSL certificate"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /ssl_check [domain]")
                return

            domain = args[1]
            
            context = ssl.create_default_context()
            with context.wrap_socket(socket.socket(), server_hostname=domain) as s:
                s.connect((domain, 443))
                cert = s.getpeercert()
            
            result = f"""🔒 Informasi SSL untuk {domain}:

📜 Subject: {cert['subject']}
🏢 Issuer: {cert['issuer']}
📅 Valid Dari: {cert['notBefore']}
📅 Valid Sampai: {cert['notAfter']}
🔑 Version: {cert['version']}
📝 Serial Number: {cert['serialNumber']}
"""

            self.bot.reply_to(message, add_watermark(result))

        except Exception as e:
            self.logger.error(f"Error in ssl_check: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal memeriksa sertifikat SSL")

    def http_headers(self, message):
        """Check HTTP headers"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /http_headers [url]")
                return

            url = args[1]
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            
            response = requests.head(url, allow_redirects=True)
            
            result = f"""🌐 HTTP Headers untuk {url}:

Status: {response.status_code}
"""
            for header, value in response.headers.items():
                result += f"{header}: {value}\n"

            self.bot.reply_to(message, add_watermark(result))

        except Exception as e:
            self.logger.error(f"Error in http_headers: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan HTTP headers")

    def format_dns_records(self, records):
        """Format DNS records for output"""
        try:
            return "\n".join([f"└─ {record}" for record in records])
        except:
            return "└─ Tidak ditemukan"

def register_network_handlers(bot: TeleBot):
    handler = NetworkHandler(bot)
    handler.register_handlers()