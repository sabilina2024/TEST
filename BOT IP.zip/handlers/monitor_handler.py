import psutil
import time
import logging
from datetime import datetime, timedelta
from telebot import TeleBot
from utils.helpers import add_watermark, format_bytes
from collections import deque

class MonitorHandler:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
        # Menyimpan data monitoring untuk grafik
        self.cpu_history = deque(maxlen=60)  # 60 detik terakhir
        self.memory_history = deque(maxlen=60)
        self.network_history = deque(maxlen=60)
        self.monitoring_tasks = {}  # Untuk monitoring berkelanjutan

    def register_handlers(self):
        """Register all monitoring handlers"""
        self.bot.message_handler(commands=['monitor'])(self.show_monitor_menu)
        # Traffic Monitoring
        self.bot.message_handler(commands=['traffic_live'])(self.traffic_live)
        self.bot.message_handler(commands=['traffic_stats'])(self.traffic_stats)
        self.bot.message_handler(commands=['traffic_top'])(self.traffic_top)
        # Performance Monitoring
        self.bot.message_handler(commands=['kinerja_cek'])(self.performance_check)
        self.bot.message_handler(commands=['kinerja_lengkap'])(self.performance_full)
        self.bot.message_handler(commands=['kinerja_riwayat'])(self.performance_history)
        # Resource Monitoring
        self.bot.message_handler(commands=['sumber_cpu'])(self.monitor_cpu)
        self.bot.message_handler(commands=['sumber_ram'])(self.monitor_ram)
        self.bot.message_handler(commands=['sumber_disk'])(self.monitor_disk)
        # Continuous Monitoring
        self.bot.message_handler(commands=['monitor_start'])(self.start_monitoring)
        self.bot.message_handler(commands=['monitor_stop'])(self.stop_monitoring)
        self.bot.message_handler(commands=['monitor_status'])(self.monitoring_status)

    def show_monitor_menu(self, message):
        """Show monitoring tools menu"""
        monitor_text = """
📊 Alat Pemantauan:

1. Pemantauan Traffic:
/traffic_live - Traffic langsung
/traffic_stats - Statistik traffic
/traffic_top - Pengguna teratas

2. Pemantauan Kinerja:
/kinerja_cek - Cek kinerja dasar
/kinerja_lengkap - Cek kinerja lengkap
/kinerja_riwayat - Data historis

3. Pemantauan Sumber Daya:
/sumber_cpu - Penggunaan CPU
/sumber_ram - Penggunaan RAM
/sumber_disk - Penggunaan disk

4. Pemantauan Berkelanjutan:
/monitor_start [interval] - Mulai pemantauan
/monitor_stop - Hentikan pemantauan
/monitor_status - Status pemantauan

Contoh:
- /traffic_live
- /monitor_start 60
"""
        self.bot.reply_to(message, monitor_text)

    def traffic_live(self, message):
        """Monitor live network traffic"""
        try:
            # Get initial network stats
            net1 = psutil.net_io_counters()
            time.sleep(1)
            net2 = psutil.net_io_counters()
            
            # Calculate speed
            bytes_sent = net2.bytes_sent - net1.bytes_sent
            bytes_recv = net2.bytes_recv - net1.bytes_recv
            
            result = f"""🌐 Traffic Network Live:

↑ Upload: {format_bytes(bytes_sent)}/s
↓ Download: {format_bytes(bytes_recv)}/s

📊 Total:
└─ Terkirim: {format_bytes(net2.bytes_sent)}
└─ Diterima: {format_bytes(net2.bytes_recv)}
└─ Paket Terkirim: {net2.packets_sent}
└─ Paket Diterima: {net2.packets_recv}
└─ Errors In: {net2.errin}
└─ Errors Out: {net2.errout}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in traffic_live: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal memantau traffic network")

    def traffic_stats(self, message):
        """Show network traffic statistics"""
        try:
            # Get network interfaces
            interfaces = psutil.net_if_stats()
            addresses = psutil.net_if_addrs()
            
            result = "📊 Statistik Network:\n\n"
            
            for interface, stats in interfaces.items():
                result += f"📡 Interface: {interface}\n"
                result += f"└─ Status: {'✅ Up' if stats.isup else '❌ Down'}\n"
                result += f"└─ Speed: {stats.speed} Mbps\n"
                result += f"└─ MTU: {stats.mtu}\n"
                
                # Add IP addresses
                if interface in addresses:
                    for addr in addresses[interface]:
                        if addr.family == 2:  # IPv4
                            result += f"└─ IPv4: {addr.address}\n"
                        elif addr.family == 23:  # IPv6
                            result += f"└─ IPv6: {addr.address}\n"
                result += "\n"
                
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in traffic_stats: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan statistik traffic")

    def traffic_top(self, message):
        """Show top network connections"""
        try:
            connections = psutil.net_connections()
            
            # Group connections by program
            conn_stats = {}
            for conn in connections:
                try:
                    if conn.pid:
                        process = psutil.Process(conn.pid)
                        prog_name = process.name()
                        if prog_name not in conn_stats:
                            conn_stats[prog_name] = {
                                'count': 0,
                                'status': {'ESTABLISHED': 0, 'LISTEN': 0, 'CLOSE_WAIT': 0}
                            }
                        conn_stats[prog_name]['count'] += 1
                        conn_stats[prog_name]['status'][conn.status] = \
                            conn_stats[prog_name]['status'].get(conn.status, 0) + 1
                except:
                    continue
            
            # Sort by connection count
            sorted_stats = sorted(conn_stats.items(), 
                                key=lambda x: x[1]['count'], 
                                reverse=True)[:10]
            
            result = "🔝 Top Network Connections:\n\n"
            for prog_name, stats in sorted_stats:
                result += f"📱 {prog_name}:\n"
                result += f"└─ Total Koneksi: {stats['count']}\n"
                result += f"└─ ESTABLISHED: {stats['status']['ESTABLISHED']}\n"
                result += f"└─ LISTEN: {stats['status']['LISTEN']}\n"
                result += f"└─ CLOSE_WAIT: {stats['status']['CLOSE_WAIT']}\n\n"
                
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in traffic_top: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan top connections")

    def performance_check(self, message):
        """Basic performance check"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            result = f"""📊 Cek Kinerja Dasar:

💻 CPU: {cpu_percent}%
💾 RAM: {memory.percent}%
💽 Disk: {disk.percent}%

Status:
{'✅' if cpu_percent < 80 else '⚠️'} CPU {'Normal' if cpu_percent < 80 else 'Tinggi'}
{'✅' if memory.percent < 80 else '⚠️'} RAM {'Normal' if memory.percent < 80 else 'Tinggi'}
{'✅' if disk.percent < 80 else '⚠️'} Disk {'Normal' if disk.percent < 80 else 'Penuh'}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in performance_check: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal melakukan cek kinerja")

    def performance_full(self, message):
        """Detailed performance analysis"""
        try:
            # CPU Info
            cpu_percent = psutil.cpu_percent(interval=1, percpu=True)
            cpu_freq = psutil.cpu_freq()
            
            # Memory Info
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            # Disk IO
            disk_io = psutil.disk_io_counters()
            
            # Network IO
            net_io = psutil.net_io_counters()
            
            result = f"""📊 Analisis Kinerja Lengkap:

💻 CPU:
└─ Per Core: {cpu_percent}
└─ Freq Current: {cpu_freq.current:.2f} MHz
└─ Freq Min: {cpu_freq.min:.2f} MHz
└─ Freq Max: {cpu_freq.max:.2f} MHz

💾 Memory:
└─ Total: {format_bytes(memory.total)}
└─ Available: {format_bytes(memory.available)}
└─ Used: {format_bytes(memory.used)} ({memory.percent}%)
└─ Swap Used: {format_bytes(swap.used)} ({swap.percent}%)

💽 Disk IO:
└─ Read: {format_bytes(disk_io.read_bytes)}
└─ Write: {format_bytes(disk_io.write_bytes)}
└─ Read Time: {disk_io.read_time} ms
└─ Write Time: {disk_io.write_time} ms

🌐 Network IO:
└─ Sent: {format_bytes(net_io.bytes_sent)}
└─ Received: {format_bytes(net_io.bytes_recv)}
└─ Packets Sent: {net_io.packets_sent}
└─ Packets Recv: {net_io.packets_recv}

⚡ Load Average: {[round(x, 2) for x in psutil.getloadavg()]}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in performance_full: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal melakukan analisis kinerja lengkap")

    def performance_history(self, message):
        """Show performance history"""
        try:
            result = "📈 Riwayat Kinerja:\n\n"
            
            if len(self.cpu_history) > 0:
                avg_cpu = sum(self.cpu_history) / len(self.cpu_history)
                result += f"CPU (rata-rata): {avg_cpu:.1f}%\n"
                result += self.create_ascii_graph(self.cpu_history) + "\n\n"
            
            if len(self.memory_history) > 0:
                avg_mem = sum(self.memory_history) / len(self.memory_history)
                result += f"Memory (rata-rata): {avg_mem:.1f}%\n"
                result += self.create_ascii_graph(self.memory_history) + "\n\n"
            
            if not self.cpu_history and not self.memory_history:
                result += "❌ Belum ada data historis. Gunakan /monitor_start untuk mulai mengumpulkan data."
            
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in performance_history: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal menampilkan riwayat kinerja")

    def monitor_cpu(self, message):
        """Monitor CPU usage"""
        try:
            cpu_times = psutil.cpu_times_percent()
            cpu_freq = psutil.cpu_freq()
            cpu_percent = psutil.cpu_percent(interval=1, percpu=True)
            
            result = f"""💻 Monitor CPU:

Penggunaan per Core: {cpu_percent}%

Detail Penggunaan:
└─ User: {cpu_times.user}%
└─ System: {cpu_times.system}%
└─ Idle: {cpu_times.idle}%

Frekuensi:
└─ Current: {cpu_freq.current:.2f} MHz
└─ Min: {cpu_freq.min:.2f} MHz
└─ Max: {cpu_freq.max:.2f} MHz

Load Average: {[round(x, 2) for x in psutil.getloadavg()]}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in monitor_cpu: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal memonitor CPU")

    def monitor_ram(self, message):
        """Monitor RAM usage"""
        try:
            memory = psutil.virtual_memory()
            swap = psutil.swap_memory()
            
            result = f"""💾 Monitor RAM:

Memory:
└─ Total: {format_bytes(memory.total)}
└─ Available: {format_bytes(memory.available)}
└─ Used: {format_bytes(memory.used)} ({memory.percent}%)
└─ Free: {format_bytes(memory.free)}
└─ Cache: {format_bytes(memory.cached)}
└─ Buffers: {format_bytes(memory.buffers)}

Swap:
└─ Total: {format_bytes(swap.total)}
└─ Used: {format_bytes(swap.used)} ({swap.percent}%)
└─ Free: {format_bytes(swap.free)}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in monitor_ram: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal memonitor RAM")

    def monitor_disk(self, message):
        """Monitor disk usage"""
        try:
            partitions = psutil.disk_partitions()
            io_counters = psutil.disk_io_counters()
            
            result = "💽 Monitor Disk:\n\n"
            
            # Partitions info
            result += "Partisi:\n"
            for partition in partitions:
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    result += f"📁 {partition.device} ({partition.mountpoint}):\n"
                    result += f"└─ Total: {format_bytes(usage.total)}\n"
                    result += f"└─ Used: {format_bytes(usage.used)} ({usage.percent}%)\n"
                    result += f"└─ Free: {format_bytes(usage.free)}\n"
                    result += f"└─ File System: {partition.fstype}\n\n"
                except:
                    continue
            
            # IO Statistics
            result += "IO Statistics:\n"
            result += f"└─ Read: {format_bytes(io_counters.read_bytes)}\n"
            result += f"└─ Write: {format_bytes(io_counters.write_bytes)}\n"
            result += f"└─ Read Count: {io_counters.read_count}\n"
            result += f"└─ Write Count: {io_counters.write_count}\n"
            
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in monitor_disk: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal memonitor disk")

    def start_monitoring(self, message):
        """Start continuous monitoring"""
        try:
            args = message.text.split()
            interval = 60  # default 60 seconds
            if len(args) > 1:
                try:
                    interval = int(args[1])
                    if interval < 30:
                        self.bot.reply_to(message, "⚠️ Interval minimum adalah 30 detik")
                        return
                except:
                    self.bot.reply_to(message, "❌ Interval harus berupa angka")
                    return
            
            chat_id = message.chat.id
            if chat_id in self.monitoring_tasks:
                self.bot.reply_to(message, "⚠️ Monitoring sudah berjalan")
                return
                
            self.monitoring_tasks[chat_id] = {
                'interval': interval,
                'last_update': datetime.now(),
                'active': True
            }
            
            self.bot.reply_to(message, 
                f"✅ Monitoring dimulai dengan interval {interval} detik")
            
            # Start monitoring loop
            self.monitoring_loop(chat_id)
            
        except Exception as e:
            self.logger.error(f"Error in start_monitoring: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal memulai monitoring")

    def stop_monitoring(self, message):
        """Stop continuous monitoring"""
        try:
            chat_id = message.chat.id
            if chat_id in self.monitoring_tasks:
                self.monitoring_tasks[chat_id]['active'] = False
                del self.monitoring_tasks[chat_id]
                self.bot.reply_to(message, "✅ Monitoring dihentikan")
            else:
                self.bot.reply_to(message, "⚠️ Tidak ada monitoring yang aktif")
                
        except Exception as e:
            self.logger.error(f"Error in stop_monitoring: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal menghentikan monitoring")

    def monitoring_status(self, message):
        """Show monitoring status"""
        try:
            chat_id = message.chat.id
            if chat_id in self.monitoring_tasks:
                task = self.monitoring_tasks[chat_id]
                elapsed = datetime.now() - task['last_update']
                
                result = f"""📊 Status Monitoring:

✅ Status: Aktif
⏱️ Interval: {task['interval']} detik
🕒 Update Terakhir: {elapsed.seconds} detik yang lalu
📈 Data Terkumpul:
└─ CPU: {len(self.cpu_history)} sampel
└─ Memory: {len(self.memory_history)} sampel
"""
            else:
                result = "📊 Status Monitoring:\n\n❌ Tidak ada monitoring yang aktif"
                
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in monitoring_status: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan status monitoring")

    def monitoring_loop(self, chat_id):
        """Background monitoring loop"""
        try:
            if chat_id not in self.monitoring_tasks or \
               not self.monitoring_tasks[chat_id]['active']:
                return
                
            task = self.monitoring_tasks[chat_id]
            
            # Collect data
            cpu_percent = psutil.cpu_percent()
            memory_percent = psutil.virtual_memory().percent
            
            self.cpu_history.append(cpu_percent)
            self.memory_history.append(memory_percent)
            
            # Check thresholds
            if cpu_percent > 80 or memory_percent > 80:
                self.bot.send_message(
                    chat_id,
                    f"⚠️ Peringatan:\nCPU: {cpu_percent}%\nMemory: {memory_percent}%"
                )
            
            # Schedule next update
            task['last_update'] = datetime.now()
            time.sleep(task['interval'])
            
            # Continue loop
            self.monitoring_loop(chat_id)
            
        except Exception as e:
            self.logger.error(f"Error in monitoring_loop: {str(e)}")
            self.monitoring_tasks[chat_id]['active'] = False

    def create_ascii_graph(self, data, width=20, height=5):
        """Create simple ASCII graph"""
        if not data:
            return ""
            
        min_val = min(data)
        max_val = max(data)
        range_val = max_val - min_val or 1
        
        graph = ""
        for i in range(height-1, -1, -1):
            line = ""
            threshold = min_val + (range_val * i / (height-1))
            for value in data[-width:]:
                if value >= threshold:
                    line += "█"
                else:
                    line += " "
            graph += line + "\n"
            
        return graph

def register_monitor_handlers(bot: TeleBot):
    handler = MonitorHandler(bot)
    handler.register_handlers()