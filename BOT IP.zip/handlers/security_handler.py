import hashlib
import base64
import secrets
import string
import jwt
import bcrypt
import re
import logging
import json
from datetime import datetime, timedelta
from telebot import TeleBot
from utils.helpers import add_watermark
from pathlib import Path
import requests
import subprocess

class SecurityHandler:
    def __init__(self, bot: TeleBot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
        self.password_history = {}
        self.secret_key = secrets.token_hex(32)
        self.blocked_ips = set()
        self.attack_logs = []
        self.security_rules = self.load_security_rules()

    def register_handlers(self):
        """Register all security handlers"""
        self.bot.message_handler(commands=['security'])(self.show_security_menu)
        # Hash Tools
        self.bot.message_handler(commands=['hash_generate'])(self.generate_hash)
        self.bot.message_handler(commands=['hash_verify'])(self.verify_hash)
        self.bot.message_handler(commands=['hash_crack'])(self.crack_hash)
        # Password Tools
        self.bot.message_handler(commands=['pwd_generate'])(self.generate_password)
        self.bot.message_handler(commands=['pwd_check'])(self.check_password)
        self.bot.message_handler(commands=['pwd_encrypt'])(self.encrypt_password)
        # Token Tools
        self.bot.message_handler(commands=['token_generate'])(self.generate_token)
        self.bot.message_handler(commands=['token_verify'])(self.verify_token)
        self.bot.message_handler(commands=['token_decode'])(self.decode_token)
        # Security Analysis
        self.bot.message_handler(commands=['security_scan'])(self.security_scan)
        self.bot.message_handler(commands=['security_check'])(self.security_check)
        self.bot.message_handler(commands=['security_report'])(self.security_report)
        # Firewall Management
        self.bot.message_handler(commands=['fw_status'])(self.firewall_status)
        self.bot.message_handler(commands=['fw_block'])(self.block_ip)
        self.bot.message_handler(commands=['fw_unblock'])(self.unblock_ip)

    def show_security_menu(self, message):
        """Show security tools menu"""
        security_text = """
🔒 Alat Keamanan:

1. Alat Hash:
/hash_generate [teks] [algo] - Generate hash
/hash_verify [hash] [teks] - Verifikasi hash
/hash_crack [hash] - Crack hash

2. Alat Password:
/pwd_generate [panjang] - Generate password
/pwd_check [password] - Cek kekuatan password
/pwd_encrypt [password] - Enkripsi password

3. Alat Token:
/token_generate [data] - Generate JWT token
/token_verify [token] - Verifikasi token
/token_decode [token] - Decode token

4. Analisis Keamanan:
/security_scan [target] - Scan keamanan
/security_check [url] - Cek kerentanan
/security_report - Laporan keamanan

5. Manajemen Firewall:
/fw_status - Status firewall
/fw_block [ip] - Block IP
/fw_unblock [ip] - Unblock IP

Contoh:
- /hash_generate password md5
- /pwd_generate 16
- /security_scan example.com
"""
        self.bot.reply_to(message, security_text)

    def generate_hash(self, message):
        """Generate hash from text"""
        try:
            args = message.text.split()
            if len(args) < 3:
                self.bot.reply_to(message, "Format: /hash_generate [teks] [algo]")
                return

            text = args[1]
            algo = args[2].lower()
            
            algorithms = {
                'md5': hashlib.md5,
                'sha1': hashlib.sha1,
                'sha256': hashlib.sha256,
                'sha512': hashlib.sha512
            }
            
            if algo not in algorithms:
                self.bot.reply_to(message, "❌ Algoritma tidak didukung")
                return
            
            hash_obj = algorithms[algo]()
            hash_obj.update(text.encode())
            hash_result = hash_obj.hexdigest()
            
            result = f"""🔐 Hash Generator:

📝 Teks: {text}
🔧 Algoritma: {algo.upper()}
📊 Hash: {hash_result}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in generate_hash: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal generate hash")

    def verify_hash(self, message):
        """Verify hash against text"""
        try:
            args = message.text.split()
            if len(args) < 3:
                self.bot.reply_to(message, "Format: /hash_verify [hash] [teks]")
                return

            hash_value = args[1]
            text = args[2]
            
            # Try different algorithms
            algorithms = ['md5', 'sha1', 'sha256', 'sha512']
            matches = []
            
            for algo in algorithms:
                hash_obj = getattr(hashlib, algo)()
                hash_obj.update(text.encode())
                if hash_obj.hexdigest() == hash_value:
                    matches.append(algo)
            
            if matches:
                result = f"""✅ Hash Terverifikasi:

🔑 Hash: {hash_value}
📝 Teks: {text}
🔧 Algoritma yang cocok: {', '.join(matches).upper()}
"""
            else:
                result = "❌ Hash tidak cocok dengan teks"
            
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in verify_hash: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal verifikasi hash")

    def crack_hash(self, message):
        """Attempt to crack hash using common wordlist"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /hash_crack [hash]")
                return

            hash_value = args[1].lower()
            
            # Load common passwords
            common_passwords = [
                "123456", "password", "12345678", "qwerty", 
                "abc123", "111111", "123123", "admin"
            ]
            
            result = f"🔍 Mencoba crack hash: {hash_value}\n\n"
            found = False
            
            for password in common_passwords:
                # Try different algorithms
                for algo in ['md5', 'sha1', 'sha256', 'sha512']:
                    hash_obj = getattr(hashlib, algo)()
                    hash_obj.update(password.encode())
                    if hash_obj.hexdigest() == hash_value:
                        result += f"✅ Hash berhasil di-crack!\n"
                        result += f"📝 Password: {password}\n"
                        result += f"🔧 Algoritma: {algo.upper()}"
                        found = True
                        break
                if found:
                    break
            
            if not found:
                result += "❌ Hash tidak ditemukan dalam wordlist"
            
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in crack_hash: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal crack hash")

    def generate_password(self, message):
        """Generate secure password"""
        try:
            args = message.text.split()
            length = 16  # default length
            if len(args) > 1:
                length = int(args[1])
                if length < 8:
                    self.bot.reply_to(message, "⚠️ Panjang minimum password adalah 8 karakter")
                    return
                if length > 64:
                    self.bot.reply_to(message, "⚠️ Panjang maksimum password adalah 64 karakter")
                    return
            
            # Generate password with all character types
            lowercase = string.ascii_lowercase
            uppercase = string.ascii_uppercase
            digits = string.digits
            symbols = string.punctuation
            
            # Ensure at least one of each type
            password = [
                secrets.choice(lowercase),
                secrets.choice(uppercase),
                secrets.choice(digits),
                secrets.choice(symbols)
            ]
            
            # Fill the rest randomly
            all_characters = lowercase + uppercase + digits + symbols
            for _ in range(length - 4):
                password.append(secrets.choice(all_characters))
            
            # Shuffle password
            secrets.SystemRandom().shuffle(password)
            password = ''.join(password)
            
            result = f"""🔐 Password Generator:

📝 Password: {password}
📊 Panjang: {length}
💪 Kekuatan: Sangat Kuat
✅ Memenuhi kriteria:
└─ Huruf kecil
└─ Huruf besar
└─ Angka
└─ Simbol
"""
            # Store in history
            self.password_history[message.chat.id] = {
                'password': password,
                'generated': datetime.now()
            }
            
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in generate_password: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal generate password")

    def check_password(self, message):
        """Check password strength"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /pwd_check [password]")
                return

            password = args[1]
            score = 0
            checks = []
            
            # Length check
            if len(password) >= 12:
                score += 2
                checks.append("✅ Panjang > 12")
            elif len(password) >= 8:
                score += 1
                checks.append("✅ Panjang > 8")
            else:
                checks.append("❌ Panjang < 8")
            
            # Character type checks
            if re.search(r"[a-z]", password):
                score += 1
                checks.append("✅ Huruf kecil")
            if re.search(r"[A-Z]", password):
                score += 1
                checks.append("✅ Huruf besar")
            if re.search(r"\d", password):
                score += 1
                checks.append("✅ Angka")
            if re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
                score += 1
                checks.append("✅ Simbol")
            
            # Common patterns check
            if not re.search(r"123|abc|qwerty|password", password.lower()):
                score += 1
                checks.append("✅ Tidak ada pola umum")
            else:
                checks.append("❌ Mengandung pola umum")
            
            # Determine strength
            strength = "Sangat Lemah"
            if score >= 6:
                strength = "Sangat Kuat"
            elif score >= 4:
                strength = "Kuat"
            elif score >= 3:
                strength = "Sedang"
            elif score >= 2:
                strength = "Lemah"
            
            result = f"""🔍 Password Checker:

💪 Kekuatan: {strength}
📊 Skor: {score}/7

✅ Hasil Check:
{chr(10).join(checks)}

🔧 Rekomendasi:
{'✅ Password aman digunakan' if score >= 4 else '⚠️ Sebaiknya gunakan password yang lebih kuat'}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in check_password: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal check password")

    def encrypt_password(self, message):
        """Encrypt password using bcrypt"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /pwd_encrypt [password]")
                return

            password = args[1]
            
            # Generate salt and hash
            salt = bcrypt.gensalt()
            hashed = bcrypt.hashpw(password.encode(), salt)
            
            result = f"""🔒 Password Encryption:

📝 Password: {password}
🧂 Salt: {salt.decode()}
🔐 Hash: {hashed.decode()}

ℹ️ Menggunakan bcrypt dengan salt
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in encrypt_password: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal encrypt password")

    def generate_token(self, message):
        """Generate JWT token"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /token_generate [data]")
                return

            data = args[1]
            
            # Create token payload
            payload = {
                'data': data,
                'exp': datetime.utcnow() + timedelta(hours=1),
                'iat': datetime.utcnow()
            }
            
            # Generate token
            token = jwt.encode(payload, self.secret_key, algorithm='HS256')
            
            result = f"""🔑 Token Generator:

📝 Data: {data}
🎟️ Token: {token}
⏰ Expires: {payload['exp']}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in generate_token: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal generate token")

    def verify_token(self, message):
        """Verify JWT token"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /token_verify [token]")
                return

            token = args[1]
            
            try:
                # Verify and decode token
                payload = jwt.decode(token, self.secret_key, algorithms=['HS256'])
                result = f"""✅ Token Valid:

📝 Data: {payload.get('data')}
⏰ Issued At: {datetime.fromtimestamp(payload['iat'])}
⏰ Expires: {datetime.fromtimestamp(payload['exp'])}
"""
            except jwt.ExpiredSignatureError:
                result = "❌ Token telah kedaluwarsa"
            except jwt.InvalidTokenError:
                result = "❌ Token tidak valid"
            
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in verify_token: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal verifikasi token")

    def decode_token(self, message):
        """Decode JWT token without verification"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /token_decode [token]")
                return

            token = args[1]
            
            # Decode token without verification
            header = jwt.get_unverified_header(token)
            payload = jwt.decode(token, options={"verify_signature": False})
            
            result = f"""🔍 Token Decoder:

Header:
{json.dumps(header, indent=2)}

Payload:
{json.dumps(payload, indent=2)}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in decode_token: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal decode token")

    def security_scan(self, message):
        """Perform security scan"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /security_scan [target]")
                return

            target = args[1]
            
            # Basic security checks
            checks = [
                self.check_ssl(target),
                self.check_headers(target),
                self.check_ports(target),
                self.check_dns(target)
            ]
            
            result = f"""🔒 Hasil Security Scan untuk {target}:

{chr(10).join(checks)}

⚠️ Catatan: Ini adalah scan dasar.
Untuk analisis mendalam, gunakan tools khusus.
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in security_scan: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal melakukan security scan")

    def security_check(self, message):
        """Check for common vulnerabilities"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /security_check [url]")
                return

            url = args[1]
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            
            # Perform security checks
            results = []
            
            # Check HTTPS
            if url.startswith('https://'):
                results.append("✅ HTTPS digunakan")
            else:
                results.append("❌ HTTPS tidak digunakan")
            
            # Check security headers
            response = requests.head(url)
            headers = response.headers
            
            if 'Strict-Transport-Security' in headers:
                results.append("✅ HSTS aktif")
            else:
                results.append("❌ HSTS tidak aktif")
                
            if 'X-Frame-Options' in headers:
                results.append("✅ X-Frame-Options diatur")
            else:
                results.append("❌ X-Frame-Options tidak diatur")
                
            if 'X-Content-Type-Options' in headers:
                results.append("✅ X-Content-Type-Options diatur")
            else:
                results.append("❌ X-Content-Type-Options tidak diatur")
            
            result = f"""🔍 Security Check untuk {url}:

{chr(10).join(results)}

📊 Skor Keamanan: {results.count('✅')}/{len(results)}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in security_check: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal melakukan security check")

    def security_report(self, message):
        """Generate security report"""
        try:
            # Collect security metrics
            blocked_count = len(self.blocked_ips)
            attack_count = len(self.attack_logs)
            
            result = f"""📊 Laporan Keamanan:

🚫 IP Diblokir: {blocked_count}
⚠️ Serangan Terdeteksi: {attack_count}
📅 Periode: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

🔍 Detail Serangan Terakhir:
{self.format_attack_logs()}

🛡️ Rekomendasi:
{self.generate_security_recommendations()}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in security_report: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal membuat laporan keamanan")

    def firewall_status(self, message):
        """Show firewall status"""
        try:
            # Get firewall rules (simplified)
            result = f"""🛡️ Status Firewall:

📊 Statistik:
└─ IP Diblokir: {len(self.blocked_ips)}
└─ Rules Aktif: {len(self.security_rules)}

⛔ IP Terblokir:
{chr(10).join(['└─ ' + ip for ip in list(self.blocked_ips)[:5]])}
{'...' if len(self.blocked_ips) > 5 else ''}

✅ Rules Aktif:
{self.format_security_rules()}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in firewall_status: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal mendapatkan status firewall")

    def block_ip(self, message):
        """Block an IP address"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /fw_block [ip]")
                return

            ip = args[1]
            
            # Validate IP
            try:
                socket.inet_aton(ip)
            except socket.error:
                self.bot.reply_to(message, "❌ IP address tidak valid")
                return
            
            if ip in self.blocked_ips:
                self.bot.reply_to(message, "⚠️ IP sudah diblokir")
                return
            
            self.blocked_ips.add(ip)
            self.attack_logs.append({
                'time': datetime.now(),
                'ip': ip,
                'action': 'blocked',
                'reason': 'manual block'
            })
            
            result = f"""✅ IP Berhasil Diblokir:

🌐 IP: {ip}
⏰ Waktu: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in block_ip: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal memblokir IP")

    def unblock_ip(self, message):
        """Unblock an IP address"""
        try:
            args = message.text.split()
            if len(args) < 2:
                self.bot.reply_to(message, "Format: /fw_unblock [ip]")
                return

            ip = args[1]
            
            if ip not in self.blocked_ips:
                self.bot.reply_to(message, "⚠️ IP tidak dalam daftar blokir")
                return
            
            self.blocked_ips.remove(ip)
            self.attack_logs.append({
                'time': datetime.now(),
                'ip': ip,
                'action': 'unblocked',
                'reason': 'manual unblock'
            })
            
            result = f"""✅ IP Berhasil Diunblock:

🌐 IP: {ip}
⏰ Waktu: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
            self.bot.reply_to(message, add_watermark(result))
            
        except Exception as e:
            self.logger.error(f"Error in unblock_ip: {str(e)}")
            self.bot.reply_to(message, "❌ Gagal unblock IP")

    def load_security_rules(self):
        """Load security rules from file"""
        try:
            rules_file = Path('config/security_rules.json')
            if rules_file.exists():
                with open(rules_file, 'r') as f:
                    return json.load(f)
            return []
        except:
            return []

    def format_attack_logs(self):
        """Format attack logs for display"""
        if not self.attack_logs:
            return "Tidak ada serangan terdeteksi"
            
        logs = []
        for log in self.attack_logs[-5:]:  # Show last 5 logs
            logs.append(
                f"⏰ {log['time'].strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"└─ IP: {log['ip']}\n"
                f"└─ Action: {log['action']}\n"
                f"└─ Reason: {log['reason']}"
            )
        return "\n\n".join(logs)

    def generate_security_recommendations(self):
        """Generate security recommendations"""
        recs = []
        
        if len(self.blocked_ips) > 10:
            recs.append("⚠️ Tinjau daftar IP yang diblokir")
            
        if len(self.attack_logs) > 0:
            recs.append("⚠️ Analisis pola serangan")
            
        if not self.security_rules:
            recs.append("⚠️ Tambahkan rules keamanan")
            
        if not recs:
            recs.append("✅ Tidak ada rekomendasi khusus")
            
        return "\n".join(recs)

    def format_security_rules(self):
        """Format security rules for display"""
        if not self.security_rules:
            return "Tidak ada rules yang aktif"
            
        rules = []
        for rule in self.security_rules[:5]:  # Show first 5 rules
            rules.append(f"└─ {rule['name']}: {rule['description']}")
        
        if len(self.security_rules) > 5:
            rules.append("...")
            
        return "\n".join(rules)

    def check_ssl(self, target):
        """Check SSL certificate"""
        try:
            response = requests.get(f"https://{target}", verify=True)
            return "✅ SSL Valid"
        except:
            return "❌ SSL Invalid atau tidak ada"

    def check_headers(self, target):
        """Check security headers"""
        try:
            response = requests.head(f"https://{target}")
            headers = response.headers
            
            results = []
            if 'Strict-Transport-Security' in headers:
                results.append("✅ HSTS aktif")
            if 'X-Frame-Options' in headers:
                results.append("✅ X-Frame-Options diatur")
            if 'X-Content-Type-Options' in headers:
                results.append("✅ X-Content-Type-Options diatur")
                
            return "\n".join(results) if results else "❌ Headers keamanan tidak ditemukan"
        except:
            return "❌ Gagal check headers"

    def check_ports(self, target):
        """Check open ports"""
        try:
            common_ports = [21, 22, 23, 80, 443]
            open_ports = []
            
            for port in common_ports:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((target, port))
                if result == 0:
                    open_ports.append(str(port))
                sock.close()
                
            return f"📍 Port terbuka: {', '.join(open_ports)}"
        except:
            return "❌ Gagal check port"

    def check_dns(self, target):
        """Check DNS records"""
        try:
            records = dns.resolver.resolve(target, 'A')
            return f"📍 DNS A records: {', '.join([str(r) for r in records])}"
        except:
            return "❌ Gagal check DNS"

def register_security_handlers(bot: TeleBot):
    handler = SecurityHandler(bot)
    handler.register_handlers()