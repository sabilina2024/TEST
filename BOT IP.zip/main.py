import os
import telebot
import logging
from pathlib import Path
from datetime import datetime
from config.config_loader import ConfigLoader
from utils.logger import setup_logger
from utils.setup import BotSetup
from handlers.scan_handler import register_scan_handlers
from handlers.monitor_handler import register_monitor_handlers
from handlers.security_handler import register_security_handlers
from handlers.network_handler import register_network_handlers
from handlers.system_handler import register_system_handlers
from handlers.export_handler import register_export_handlers

class NetworkToolsBot:
    def __init__(self):
        # Setup logging
        self.logger = setup_logger()
        self.logger.info("Initializing Network Tools Bot...")

        # Load configuration
        try:
            self.config = ConfigLoader()
            self.logger.info("Configuration loaded successfully")
        except Exception as e:
            self.logger.error(f"Failed to load configuration: {str(e)}")
            raise

        # Setup bot folders and structure
        try:
            self.setup = BotSetup()
            if not self.setup.setup():
                raise Exception("Failed to setup bot structure")
            self.logger.info("Bot structure setup completed")
        except Exception as e:
            self.logger.error(f"Failed to setup bot structure: {str(e)}")
            raise

        # Initialize bot
        try:
            self.bot = telebot.TeleBot(self.config.bot_token)
            self.logger.info("Bot initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize bot: {str(e)}")
            raise

        # Register handlers
        self.register_handlers()
        self.logger.info("All handlers registered successfully")

    def register_handlers(self):
        """Register all command handlers"""
        try:
            # Basic handlers
            self.register_basic_handlers()
            
            # Feature handlers
            if self.config.get('features', {}).get('scan', True):
                register_scan_handlers(self.bot)
            if self.config.get('features', {}).get('monitor', True):
                register_monitor_handlers(self.bot)
            if self.config.get('features', {}).get('security', True):
                register_security_handlers(self.bot)
            if self.config.get('features', {}).get('network', True):
                register_network_handlers(self.bot)
            if self.config.get('features', {}).get('system', True):
                register_system_handlers(self.bot)
            if self.config.get('features', {}).get('export', True):
                register_export_handlers(self.bot)

        except Exception as e:
            self.logger.error(f"Failed to register handlers: {str(e)}")
            raise

    def register_basic_handlers(self):
        """Register basic command handlers"""
        
        @self.bot.message_handler(commands=['start'])
        def send_welcome(message):
            """Handle /start command"""
            try:
                welcome_text = f"""
🤖 Selamat Datang di Network Tools Bot v{self.config.version}

Bot ini menyediakan berbagai tools untuk:
📡 Pemindaian Jaringan
📊 Pemantauan Sistem
🔒 Keamanan
🌐 Analisis Jaringan
⚙️ Manajemen Sistem
📤 Ekspor Data

Perintah Dasar:
/tools - Lihat semua tools
/help - Bantuan penggunaan
/about - Informasi bot
/status - Status sistem

Dibuat oleh: {self.config.author['name']}
"""
                self.bot.reply_to(message, welcome_text)
                self.logger.info(f"Welcome message sent to user {message.from_user.id}")
            except Exception as e:
                self.logger.error(f"Error in welcome message: {str(e)}")
                self.bot.reply_to(message, "❌ Terjadi kesalahan saat memproses perintah")

        @self.bot.message_handler(commands=['help'])
        def show_help(message):
            """Handle /help command"""
            try:
                help_text = """
📚 Panduan Penggunaan Bot:

1. Perintah Dasar:
/start - Mulai bot
/help - Tampilkan panduan ini
/about - Informasi bot
/status - Status sistem
/tools - Daftar semua tools

2. Kategori Tools:
/scan - Tools pemindaian
/monitor - Tools pemantauan
/security - Tools keamanan
/network - Tools jaringan
/system - Tools sistem
/export - Tools ekspor

3. Penggunaan:
- Setiap kategori memiliki sub-perintah
- Gunakan /[kategori] untuk melihat detail
- Format: /perintah [parameter]

4. Contoh:
/scan - Lihat tools pemindaian
/monitor - Lihat tools pemantauan
/security - Lihat tools keamanan

5. Tips:
- Gunakan /help [perintah] untuk bantuan spesifik
- Cek /status untuk melihat status sistem
- Laporan error dengan /report

Untuk bantuan lebih lanjut, hubungi:
{self.config.author['telegram']}
"""
                self.bot.reply_to(message, help_text)
                self.logger.info(f"Help message sent to user {message.from_user.id}")
            except Exception as e:
                self.logger.error(f"Error in help message: {str(e)}")
                self.bot.reply_to(message, "❌ Terjadi kesalahan saat memproses perintah")

        @self.bot.message_handler(commands=['about'])
        def show_about(message):
            """Handle /about command"""
            try:
                about_text = f"""
ℹ️ Tentang Network Tools Bot:

🤖 Versi: {self.config.version}
📅 Update Terakhir: {datetime.now().strftime('%Y-%m-%d')}

👨‍💻 Developer:
└─ Nama: {self.config.author['name']}
└─ Telegram: {self.config.author['telegram']}
└─ Email: {self.config.author['email']}
└─ GitHub: {self.config.author['github']}

🛠️ Fitur:
└─ Pemindaian Jaringan
└─ Pemantauan Sistem
└─ Tools Keamanan
└─ Analisis Jaringan
└─ Manajemen Sistem
└─ Ekspor Data

📝 Lisensi: MIT License
© {datetime.now().year} {self.config.author['name']}
All rights reserved.
"""
                self.bot.reply_to(message, about_text)
                self.logger.info(f"About info sent to user {message.from_user.id}")
            except Exception as e:
                self.logger.error(f"Error in about message: {str(e)}")
                self.bot.reply_to(message, "❌ Terjadi kesalahan saat memproses perintah")

        @self.bot.message_handler(commands=['status'])
        def show_status(message):
            """Handle /status command"""
            try:
                import psutil
                import platform
                
                # System info
                cpu_percent = psutil.cpu_percent()
                memory = psutil.virtual_memory()
                disk = psutil.disk_usage('/')
                boot_time = datetime.fromtimestamp(psutil.boot_time())
                
                status_text = f"""
📊 Status Sistem:

💻 Sistem:
└─ OS: {platform.system()} {platform.release()}
└─ Python: {platform.python_version()}
└─ Uptime: {(datetime.now() - boot_time).days} hari

📈 Penggunaan:
└─ CPU: {cpu_percent}%
└─ RAM: {memory.percent}%
└─ Disk: {disk.percent}%

🤖 Bot:
└─ Versi: {self.config.version}
└─ Status: 🟢 Online
└─ Fitur Aktif: {sum(self.config.get('features', {}).values())}

⚡ Status: Operasional
🕒 Waktu: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
                self.bot.reply_to(message, status_text)
                self.logger.info(f"Status info sent to user {message.from_user.id}")
            except Exception as e:
                self.logger.error(f"Error in status message: {str(e)}")
                self.bot.reply_to(message, "❌ Terjadi kesalahan saat memproses perintah")

        @self.bot.message_handler(commands=['tools'])
        def show_tools(message):
            """Handle /tools command"""
            try:
                tools_text = """
🛠️ Daftar Tools:

1️⃣ Pemindaian (/scan):
└─ Network Scanner
└─ Port Scanner
└─ Vulnerability Scanner

2️⃣ Pemantauan (/monitor):
└─ System Monitor
└─ Network Monitor
└─ Performance Monitor

3️⃣ Keamanan (/security):
└─ Security Scanner
└─ Firewall Manager
└─ Password Tools

4️⃣ Jaringan (/network):
└─ DNS Tools
└─ Whois Tools
└─ Connectivity Tools

5️⃣ Sistem (/system):
└─ System Info
└─ Process Manager
└─ Service Manager

6️⃣ Ekspor (/export):
└─ Report Generator
└─ Data Exporter
└─ Log Exporter

Gunakan /[kategori] untuk melihat detail tools.
Contoh: /scan untuk tools pemindaian
"""
                self.bot.reply_to(message, tools_text)
                self.logger.info(f"Tools list sent to user {message.from_user.id}")
            except Exception as e:
                self.logger.error(f"Error in tools message: {str(e)}")
                self.bot.reply_to(message, "❌ Terjadi kesalahan saat memproses perintah")

    def run(self):
        """Run the bot"""
        try:
            self.logger.info("Starting bot polling...")
            self.bot.polling(none_stop=True, interval=0, timeout=20)
        except Exception as e:
            self.logger.error(f"Error in bot polling: {str(e)}")
            raise

def main():
    """Main function"""
    try:
        # Initialize and run bot
        bot = NetworkToolsBot()
        bot.run()
    except Exception as e:
        logging.error(f"Fatal error: {str(e)}")
        exit(1)

if __name__ == "__main__":
    main()