import json
import os
import logging
from pathlib import Path

class ConfigLoader:
    def __init__(self):
        self.config_path = Path(__file__).parent / 'config.json'
        self.config = self.load_config()

    def load_config(self):
        try:
            if not self.config_path.exists():
                raise FileNotFoundError("Config file not found!")
            
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logging.error(f"Error loading config: {str(e)}")
            raise

    def get(self, key, default=None):
        return self.config.get(key, default)

    @property
    def bot_token(self):
        return self.config['bot_token']

    @property
    def author(self):
        return self.config['author']

    @property
    def version(self):
        return self.config['bot_version']