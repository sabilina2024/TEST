from datetime import datetime
from config.config_loader import ConfigLoader

config = ConfigLoader()

def add_watermark(result):
    return f"""{result}

─────────────────
🤖 Dibuat oleh Bot Tools Network v{config.version}
👨‍💻 Dikembangkan oleh {config.author['name']}
📱 Kontak: {config.author['telegram']}
"""

def format_bytes(size):
    """Format bytes to human readable format"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024:
            return f"{size:.2f} {unit}"
        size /= 1024