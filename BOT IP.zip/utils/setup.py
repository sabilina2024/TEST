from pathlib import Path
import logging
import shutil

class BotSetup:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.base_path = Path(__file__).parent.parent
        self.folders = {
            'exports': self.base_path / 'exports',
            'logs': self.base_path / 'logs',
            'temp': self.base_path / 'temp',
            'data': self.base_path / 'data',
            'backups': self.base_path / 'backups'
        }

    def create_folders(self):
        """Create all necessary folders"""
        for name, path in self.folders.items():
            path.mkdir(exist_ok=True)
            self.logger.info(f"Created/verified folder: {name}")

    def clean_temp_folders(self):
        """Clean temporary folders"""
        temp_folders = ['temp', 'exports']
        for folder in temp_folders:
            path = self.folders[folder]
            if path.exists():
                shutil.rmtree(path)
                path.mkdir()
                self.logger.info(f"Cleaned folder: {folder}")

    def verify_permissions(self):
        """Verify folder permissions"""
        for name, path in self.folders.items():
            try:
                # Try to create a test file
                test_file = path / '.test'
                test_file.touch()
                test_file.unlink()
                self.logger.info(f"Verified permissions for: {name}")
            except Exception as e:
                self.logger.error(f"Permission error for {name}: {str(e)}")
                raise

    def setup(self):
        """Run complete setup"""
        try:
            self.create_folders()
            self.clean_temp_folders()
            self.verify_permissions()
            return True
        except Exception as e:
            self.logger.error(f"Setup failed: {str(e)}")
            return False

    def get_path(self, folder):
        """Get path for specific folder"""
        return self.folders.get(folder)